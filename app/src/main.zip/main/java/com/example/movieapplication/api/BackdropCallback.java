package com.example.movieapplication.api;

public interface BackdropCallback {
    void onResult(String backdrop);
}