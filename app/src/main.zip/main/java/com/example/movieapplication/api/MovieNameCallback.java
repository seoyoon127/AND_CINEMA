package com.example.movieapplication.api;

public interface MovieNameCallback {
    void onResult(String movieName);
}